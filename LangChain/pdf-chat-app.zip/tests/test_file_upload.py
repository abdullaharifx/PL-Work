"""
Unit tests for file upload functionality.
Tests PDF upload, processing, and management.
"""
import pytest
import os
import tempfile
from unittest.mock import patch, MagicMock
from app import create_app
from app.extensions import db
from app.models.user import User
from app.models.pdf import PDFDocument, PDFChunk


@pytest.fixture
def app():
    """Create test Flask application."""
    app = create_app('testing')
    app.config['TESTING'] = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    app.config['WTF_CSRF_ENABLED'] = False
    app.config['UPLOAD_FOLDER'] = tempfile.mkdtemp()
    
    with app.app_context():
        db.create_all()
        yield app
        db.drop_all()


@pytest.fixture
def client(app):
    """Create test client."""
    return app.test_client()


@pytest.fixture
def logged_in_user(app, client):
    """Create and login a test user."""
    with app.app_context():
        user = User(username='testuser', email='test@example.com')
        user.set_password('testpassword')
        db.session.add(user)
        db.session.commit()
        
        # Login
        client.post('/auth/login', data={
            'username': 'testuser',
            'password': 'testpassword'
        })
        
        return user


class TestFileUpload:
    """Test file upload functionality."""
    
    def test_upload_page_requires_login(self, client):
        """Test that upload page requires authentication."""
        response = client.get('/files/upload')
        assert response.status_code == 302  # Redirect to login
    
    def test_upload_page_loads_for_authenticated_user(self, client, logged_in_user):
        """Test upload page loads for authenticated users."""
        response = client.get('/files/upload')
        assert response.status_code == 200
        assert b'Upload PDF Document' in response.data
    
    def test_files_index_page(self, client, logged_in_user):
        """Test files index page."""
        response = client.get('/files/')
        assert response.status_code == 200
        assert b'My PDF Files' in response.data
    
    @patch('app.controllers.file_upload.process_pdf_document')
    def test_upload_pdf_success(self, mock_process, client, logged_in_user, app):
        """Test successful PDF upload."""
        # Create a mock PDF file
        with tempfile.NamedTemporaryFile(suffix='.pdf', delete=False) as tmp_file:
            tmp_file.write(b'%PDF-1.4 mock pdf content')
            tmp_file.flush()
            
            with open(tmp_file.name, 'rb') as test_file:
                response = client.post('/files/upload', data={
                    'file': (test_file, 'test.pdf')
                }, follow_redirects=True)
            
            assert response.status_code == 200
            assert b'uploaded and processed successfully' in response.data
            
            # Verify document was created
            with app.app_context():
                doc = PDFDocument.query.filter_by(filename='test.pdf').first()
                assert doc is not None
                assert doc.user_id == logged_in_user.id
            
            # Cleanup
            os.unlink(tmp_file.name)
    
    def test_upload_non_pdf_file(self, client, logged_in_user):
        """Test uploading non-PDF file."""
        with tempfile.NamedTemporaryFile(suffix='.txt') as tmp_file:
            tmp_file.write(b'This is not a PDF')
            tmp_file.flush()
            
            with open(tmp_file.name, 'rb') as test_file:
                response = client.post('/files/upload', data={
                    'file': (test_file, 'test.txt')
                })
            
            assert response.status_code == 302  # Redirect back
    
    def test_upload_no_file(self, client, logged_in_user):
        """Test upload with no file selected."""
        response = client.post('/files/upload', data={})
        assert response.status_code == 302  # Redirect back


class TestPDFProcessing:
    """Test PDF processing functionality."""
    
    @patch('app.utils.extract_text_from_pdf')
    @patch('app.langchain_pipeline.VectorStore')
    def test_process_pdf_document(self, mock_vector_store, mock_extract, app, logged_in_user):
        """Test PDF document processing."""
        with app.app_context():
            # Create a test document
            doc = PDFDocument(
                filename='test.pdf',
                file_path='/tmp/test.pdf',
                user_id=logged_in_user.id,
                file_size=1024
            )
            db.session.add(doc)
            db.session.commit()
            
            # Mock text extraction
            mock_extract.return_value = {
                1: 'This is page 1 content',
                2: 'This is page 2 content'
            }
            
            # Mock vector store
            mock_vs_instance = MagicMock()
            mock_vs_instance.add_chunk.return_value = 'embedding_123'
            mock_vector_store.return_value = mock_vs_instance
            
            # Import and test the function
            from app.controllers.file_upload import process_pdf_document
            process_pdf_document(doc.id)
            
            # Verify document was processed
            db.session.refresh(doc)
            assert doc.processed is True
            assert doc.total_pages == 2
            
            # Verify chunks were created
            chunks = PDFChunk.query.filter_by(document_id=doc.id).all()
            assert len(chunks) > 0
