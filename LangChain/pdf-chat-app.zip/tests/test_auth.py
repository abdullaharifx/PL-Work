"""
Unit tests for authentication functionality.
Tests user registration, login, logout, and session management.
"""
import pytest
from app import create_app
from app.extensions import db
from app.models.user import User


@pytest.fixture
def app():
    """Create test Flask application."""
    app = create_app('testing')
    app.config['TESTING'] = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    app.config['WTF_CSRF_ENABLED'] = False
    
    with app.app_context():
        db.create_all()
        yield app
        db.drop_all()


@pytest.fixture
def client(app):
    """Create test client."""
    return app.test_client()


@pytest.fixture
def sample_user(app):
    """Create a sample user for testing."""
    with app.app_context():
        user = User(username='testuser', email='test@example.com')
        user.set_password('testpassword')
        db.session.add(user)
        db.session.commit()
        return user


class TestUserModel:
    """Test User model functionality."""
    
    def test_user_creation(self, app):
        """Test user creation and password hashing."""
        with app.app_context():
            user = User(username='newuser', email='new@example.com')
            user.set_password('password123')
            
            assert user.username == 'newuser'
            assert user.email == 'new@example.com'
            assert user.password_hash is not None
            assert user.password_hash != 'password123'
    
    def test_password_verification(self, app):
        """Test password verification."""
        with app.app_context():
            user = User(username='testuser', email='test@example.com')
            user.set_password('correctpassword')
            
            assert user.check_password('correctpassword') is True
            assert user.check_password('wrongpassword') is False


class TestAuthRoutes:
    """Test authentication routes."""
    
    def test_register_get(self, client):
        """Test registration page loads."""
        response = client.get('/auth/register')
        assert response.status_code == 200
        assert b'Create Your Account' in response.data
    
    def test_register_post_success(self, client, app):
        """Test successful user registration."""
        response = client.post('/auth/register', data={
            'username': 'newuser',
            'email': 'new@example.com',
            'password': 'password123',
            'confirm_password': 'password123'
        }, follow_redirects=True)
        
        assert response.status_code == 200
        assert b'Registration successful' in response.data
        
        # Verify user was created
        with app.app_context():
            user = User.query.filter_by(username='newuser').first()
            assert user is not None
            assert user.email == 'new@example.com'
    
    def test_register_post_validation_errors(self, client):
        """Test registration validation errors."""
        # Test missing fields
        response = client.post('/auth/register', data={
            'username': '',
            'email': 'test@example.com',
            'password': 'password123',
            'confirm_password': 'password123'
        })
        assert response.status_code == 200
        
        # Test password mismatch
        response = client.post('/auth/register', data={
            'username': 'testuser',
            'email': 'test@example.com',
            'password': 'password123',
            'confirm_password': 'different'
        })
        assert response.status_code == 200
    
    def test_login_get(self, client):
        """Test login page loads."""
        response = client.get('/auth/login')
        assert response.status_code == 200
        assert b'Login to Your Account' in response.data
    
    def test_login_post_success(self, client, sample_user):
        """Test successful login."""
        response = client.post('/auth/login', data={
            'username': 'testuser',
            'password': 'testpassword'
        }, follow_redirects=True)
        
        assert response.status_code == 200
        assert b'Welcome back' in response.data
    
    def test_login_post_invalid_credentials(self, client, sample_user):
        """Test login with invalid credentials."""
        response = client.post('/auth/login', data={
            'username': 'testuser',
            'password': 'wrongpassword'
        })
        
        assert response.status_code == 200
        assert b'Invalid username or password' in response.data
    
    def test_logout(self, client, sample_user):
        """Test user logout."""
        # Login first
        client.post('/auth/login', data={
            'username': 'testuser',
            'password': 'testpassword'
        })
        
        # Then logout
        response = client.get('/auth/logout', follow_redirects=True)
        assert response.status_code == 200
        assert b'Goodbye' in response.data
