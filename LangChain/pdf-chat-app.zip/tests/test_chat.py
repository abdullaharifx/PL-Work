"""
Unit tests for chat functionality.
Tests chat sessions, message handling, and AI integration.
"""
import pytest
import json
from unittest.mock import patch, MagicMock
from app import create_app
from app.extensions import db
from app.models.user import User
from app.models.chat import ChatSession, ChatMessage
from app.models.pdf import PDFDocument


@pytest.fixture
def app():
    """Create test Flask application."""
    app = create_app('testing')
    app.config['TESTING'] = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    app.config['WTF_CSRF_ENABLED'] = False
    
    with app.app_context():
        db.create_all()
        yield app
        db.drop_all()


@pytest.fixture
def client(app):
    """Create test client."""
    return app.test_client()


@pytest.fixture
def logged_in_user(app, client):
    """Create and login a test user."""
    with app.app_context():
        user = User(username='testuser', email='test@example.com')
        user.set_password('testpassword')
        db.session.add(user)
        db.session.commit()
        
        # Login
        client.post('/auth/login', data={
            'username': 'testuser',
            'password': 'testpassword'
        })
        
        return user


@pytest.fixture
def sample_chat_session(app, logged_in_user):
    """Create a sample chat session."""
    with app.app_context():
        session = ChatSession(
            name='Test Chat',
            user_id=logged_in_user.id
        )
        db.session.add(session)
        db.session.commit()
        return session


class TestChatSessions:
    """Test chat session management."""
    
    def test_chat_index_requires_login(self, client):
        """Test that chat index requires authentication."""
        response = client.get('/chat/')
        assert response.status_code == 302  # Redirect to login
    
    def test_chat_index_loads(self, client, logged_in_user):
        """Test chat index page loads."""
        response = client.get('/chat/')
        assert response.status_code == 200
        assert b'My Chat Sessions' in response.data
    
    def test_new_session_get(self, client, logged_in_user):
        """Test new session page loads."""
        response = client.get('/chat/new')
        assert response.status_code == 200
        assert b'Create New Chat Session' in response.data
    
    def test_new_session_post_success(self, client, logged_in_user, app):
        """Test successful session creation."""
        response = client.post('/chat/new', data={
            'session_name': 'My New Chat'
        }, follow_redirects=True)
        
        assert response.status_code == 200
        assert b'created successfully' in response.data
        
        # Verify session was created
        with app.app_context():
            session = ChatSession.query.filter_by(name='My New Chat').first()
            assert session is not None
            assert session.user_id == logged_in_user.id
    
    def test_new_session_post_validation(self, client, logged_in_user):
        """Test session creation validation."""
        # Test empty name
        response = client.post('/chat/new', data={
            'session_name': ''
        })
        assert response.status_code == 200
        assert b'Please enter a session name' in response.data
    
    def test_session_view(self, client, logged_in_user, sample_chat_session):
        """Test individual session view."""
        response = client.get(f'/chat/session/{sample_chat_session.id}')
        assert response.status_code == 200
        assert b'Test Chat' in response.data
    
    def test_session_view_unauthorized(self, client, logged_in_user, app):
        """Test accessing unauthorized session."""
        with app.app_context():
            # Create another user and session
            other_user = User(username='otheruser', email='other@example.com')
            other_user.set_password('password')
            db.session.add(other_user)
            db.session.commit()
            
            other_session = ChatSession(name='Other Chat', user_id=other_user.id)
            db.session.add(other_session)
            db.session.commit()
            
            response = client.get(f'/chat/session/{other_session.id}')
            assert response.status_code == 302  # Redirect
    
    def test_delete_session(self, client, logged_in_user, sample_chat_session, app):
        """Test session deletion."""
        response = client.post(f'/chat/delete/{sample_chat_session.id}', 
                             follow_redirects=True)
        assert response.status_code == 200
        assert b'deleted successfully' in response.data
        
        # Verify session was soft deleted
        with app.app_context():
            session = ChatSession.query.get(sample_chat_session.id)
            assert session.is_active is False


class TestChatMessages:
    """Test chat message functionality."""
    
    @patch('app.controllers.chat.ChatPipeline')
    def test_send_message_success(self, mock_pipeline, client, logged_in_user, 
                                sample_chat_session, app):
        """Test successful message sending."""
        # Create a processed PDF for the user
        with app.app_context():
            pdf = PDFDocument(
                filename='test.pdf',
                file_path='/tmp/test.pdf',
                user_id=logged_in_user.id,
                processed=True
            )
            db.session.add(pdf)
            db.session.commit()
        
        # Mock AI response
        mock_pipeline_instance = MagicMock()
        mock_pipeline_instance.generate_response.return_value = {
            'content': 'This is the AI response',
            'sources': [
                {'document_name': 'test.pdf', 'page_number': 1, 'score': 0.95}
            ],
            'error': None
        }
        mock_pipeline.return_value = mock_pipeline_instance
        
        response = client.post('/chat/api/send_message', 
                             json={
                                 'session_id': sample_chat_session.id,
                                 'message': 'What is this document about?',
                                 'template_type': 'default'
                             })
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['success'] is True
        assert 'user_message' in data
        assert 'ai_message' in data
        
        # Verify messages were saved
        with app.app_context():
            messages = ChatMessage.query.filter_by(session_id=sample_chat_session.id).all()
            assert len(messages) == 2  # User message + AI response
    
    def test_send_message_no_pdfs(self, client, logged_in_user, sample_chat_session):
        """Test sending message when no PDFs are available."""
        response = client.post('/chat/api/send_message', 
                             json={
                                 'session_id': sample_chat_session.id,
                                 'message': 'What is this document about?'
                             })
        
        assert response.status_code == 400
        data = json.loads(response.data)
        assert 'No processed PDFs found' in data['error']
    
    def test_send_message_invalid_session(self, client, logged_in_user):
        """Test sending message to invalid session."""
        response = client.post('/chat/api/send_message', 
                             json={
                                 'session_id': 99999,
                                 'message': 'Test message'
                             })
        
        assert response.status_code == 404
        data = json.loads(response.data)
        assert 'Chat session not found' in data['error']
