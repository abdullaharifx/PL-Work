"""
Unit tests for LangChain pipeline functionality.
Tests vector storage, retrieval, and response generation.
"""
import pytest
import tempfile
import os
from unittest.mock import patch, MagicMock
from app.langchain_pipeline import VectorStore, ChatPipeline


class TestVectorStore:
    """Test vector store functionality."""
    
    def setUp(self):
        """Set up test vector store."""
        self.temp_dir = tempfile.mkdtemp()
        self.vector_store = VectorStore()
        self.vector_store.index_file = os.path.join(self.temp_dir, 'test_index.bin')
        self.vector_store.metadata_file = os.path.join(self.temp_dir, 'test_metadata.json')
    
    def test_add_chunk(self):
        """Test adding a chunk to vector store."""
        self.setUp()
        
        embedding_id = self.vector_store.add_chunk(
            chunk_id=1,
            content="This is a test document chunk",
            metadata={
                'document_id': 1,
                'document_name': 'test.pdf',
                'page_number': 1,
                'chunk_index': 0
            }
        )
        
        assert embedding_id is not None
        assert self.vector_store.index.ntotal == 1
        assert embedding_id in self.vector_store.chunk_metadata
    
    def test_search_chunks(self):
        """Test searching for similar chunks."""
        self.setUp()
        
        # Add some test chunks
        self.vector_store.add_chunk(
            chunk_id=1,
            content="Machine learning is a subset of artificial intelligence",
            metadata={
                'document_id': 1,
                'document_name': 'ai.pdf',
                'page_number': 1,
                'chunk_index': 0
            }
        )
        
        self.vector_store.add_chunk(
            chunk_id=2,
            content="Python is a programming language",
            metadata={
                'document_id': 2,
                'document_name': 'python.pdf',
                'page_number': 1,
                'chunk_index': 0
            }
        )
        
        # Search for AI-related content
        results = self.vector_store.search("artificial intelligence", k=1)
        
        assert len(results) > 0
        assert results[0]['chunk_id'] == 1
        assert 'ai.pdf' in results[0]['document_name']
    
    def test_search_empty_index(self):
        """Test searching empty vector store."""
        self.setUp()
        
        results = self.vector_store.search("test query")
        assert len(results) == 0


class TestChatPipeline:
    """Test chat pipeline functionality."""
    
    @patch('app.langchain_pipeline.VectorStore')
    @patch('app.langchain_pipeline.OpenAI')
    def test_generate_response_success(self, mock_openai, mock_vector_store):
        """Test successful response generation."""
        # Mock vector store search results
        mock_vs_instance = MagicMock()
        mock_vs_instance.search.return_value = [
            {
                'chunk_id': 1,
                'content': 'Machine learning is a powerful tool',
                'document_name': 'ml.pdf',
                'page_number': 1,
                'score': 0.95,
                'metadata': {}
            }
        ]
        mock_vector_store.return_value = mock_vs_instance
        
        # Mock LLM response
        mock_llm_instance = MagicMock()
        mock_openai.return_value = mock_llm_instance
        
        # Create pipeline without API key (will use mock)
        with patch.dict(os.environ, {}, clear=True):
            pipeline = ChatPipeline()
            pipeline.llm = None  # Force mock response
            
            response = pipeline.generate_response(
                question="What is machine learning?",
                user_id=1,
                template_type='default'
            )
        
        assert response['content'] is not None
        assert len(response['sources']) > 0
        assert response['sources'][0]['document_name'] == 'ml.pdf'
        assert response['error'] is None
    
    @patch('app.langchain_pipeline.VectorStore')
    def test_generate_response_no_context(self, mock_vector_store):
        """Test response generation with no relevant context."""
        # Mock empty search results
        mock_vs_instance = MagicMock()
        mock_vs_instance.search.return_value = []
        mock_vector_store.return_value = mock_vs_instance
        
        pipeline = ChatPipeline()
        response = pipeline.generate_response(
            question="What is machine learning?",
            user_id=1
        )
        
        assert "couldn't find any relevant information" in response['content']
        assert len(response['sources']) == 0
    
    def test_get_available_templates(self):
        """Test getting available prompt templates."""
        pipeline = ChatPipeline()
        templates = pipeline.get_available_templates()
        
        assert 'default' in templates
        assert 'bullet_points' in templates
        assert 'story' in templates
        assert len(templates) >= 3
